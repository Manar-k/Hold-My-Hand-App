//
//  progressView.swift
//  HoldMyHand
//
//  Created by loka mloka on 19/08/1443 AH.
//

import SwiftUI
import Firebase

struct progressView: View {
    @State var userName = "unknown name"

    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var backButton : some View { Button(action: {
            self.presentationMode.wrappedValue.dismiss()
            }) {
                HStack {
                Image(systemName:"chevron.left") // BackButton Image
                    .aspectRatio(contentMode: .fit)
                    .foregroundColor(.blue)
                    Text("العودة") //translated Back button title
                }
            }
        }
    
    var body: some View {
      //  NavigationView{
        VStack(spacing: 20){
            HStack(){
                //450 w
                Spacer()
                    .frame(width: 300, height: 10)
                let vname = getUName()
                Text("تقدم "+vname)
                    .foregroundColor(Color(red: 84/255, green: 165/255, blue: 218/255))
                    .font(.largeTitle)
                //420 w
                Spacer()
                    .frame(width: 300, height: 10)
            
      //  NavigationLink(destination: Home(),
      //     label: {
       //     Image(systemName: "house.fill")
        //        .resizable(resizingMode: .stretch)
         //       .foregroundColor(Color(red: 84/255, green: //165/255, blue: 218/255))
          //      .frame(width: 100, height: 95)
        //})
            }
            
         Spacer()
                .frame(width: 10, height: 20)
            
        HStack(spacing: 50){
          VStack(spacing: 25){
                Text("المستوى الثالث")
                    .font(.title)
                    .foregroundColor(Color(red: 141/255, green: 208/255,blue:235/255))
                Circle()
                    .frame(width: 180, height: 180)
                    .foregroundColor(Color(red: 229/255, green: 229/255, blue: 229/255, opacity: 1.0))
          //  .overlay(
          //      .Stroke(Color .blue)
          //  )
               // .border(Color .gray)
            }
        VStack(spacing: 25){
                Text("المستوى الثاني")
                    .font(.title)
                    .foregroundColor(Color(red: 141/255, green: 208/255,blue:235/255))
                Circle()
                    .frame(width: 180, height: 180)
                    .foregroundColor(Color(red: 229/255, green: 229/255, blue: 229/255, opacity: 1.0))
        }
            
        VStack(spacing: 25){
                Text("المستوى الأول")
                    .font(.title)
                    .foregroundColor(Color(red: 141/255, green: 208/255,blue:235/255))
               Circle()
                 .frame(width: 180, height: 180)
                 .foregroundColor(Color(red: 229/255, green: 229/255, blue: 229/255, opacity: 1.0))
        }
     }
        
            Spacer()
                .frame(width: 450, height: 5)
            
    HStack(spacing: 50){
        VStack(spacing: 25){
                Text("المستوى الرابع")
                    .font(.title)
                    .foregroundColor(Color(red: 141/255, green: 208/255,blue:235/255))
                Circle()
                    .frame(width: 180, height: 180)
                    .foregroundColor(Color(red: 229/255, green: 229/255, blue: 229/255, opacity: 1.0))
          //  .overlay(
          //      .Stroke(Color .blue)
          //  )
               // .border(Color .gray)
        }
            
        VStack(spacing: 25){
            Text("المستوى الخامس")
                .font(.title)
                .foregroundColor(Color(red: 141/255, green: 208/255,blue:235/255))
            Circle()
                .frame(width: 180, height: 180)
                .foregroundColor(Color(red: 229/255, green: 229/255, blue: 229/255, opacity: 1.0))
        }
            
     }
        }.navigationBarBackButtonHidden(true)
        .navigationBarItems(leading: backButton)
    //}
     //   .navigationViewStyle(StackNavigationViewStyle())
    }
    
    func getUName()->String{
        //Database.database().isPersistenceEnabled = true
//        let settings = FirestoreSettings()
//        settings.isPersistenceEnabled = true
//        let userRef = Database.database().reference(withPath: "User")
//        userRef.keepSynced(true)
        
        let userID = Auth.auth().currentUser?.uid
        let ref = Database.database().reference()
//        ref.child("User").child(userID!).observeSingleEvent(of: .value, with: { snapshot in
//                  // Get user value
//                  let value = snapshot.value as? NSDictionary
//            userName = value?["Name"] as? String ?? ""
//                  //let user = User(Name: Name)
//
//                  // ...
//                }) { error in
//                  print(error.localizedDescription)
//                }
        ///Name
        ref.child("User/\(userID ?? "")/Name").getData(completion:  { error, snapshot in
            guard error == nil else {
                print(error!.localizedDescription)
                return;
            }
            self.userName = snapshot.value as? String ?? ""
            print("2")
            print(userName)
        });
        return userName
    }
    //get gender from database
    func getGender()->String{
        let userID = Auth.auth().currentUser?.uid
        let ref = Database.database().reference()

        ref.child("User/\(userID ?? "")/Gender").getData(completion:  { error, snapshot in
            guard error == nil else {
                print(error!.localizedDescription)
                return;
            }
            self.userName = snapshot.value as? String ?? ""
            print("2 gender")
            print(userName)
        });
        return userName
    }
    
    
    
    //child("User")
//    func getUserName() ->String{
//        let ref = Database.database().reference().child("User")
//        let uid = Auth.auth().currentUser?.uid
//
//        ref.child(uid!).observeSingleEvent(of: .value, with: { snapshot in guard let value = snapshot.value as? String  else {
//            return
//        }
//        print(value)
//        self.userName = value
//        })
//
////
////          if let dictionary = snapshot.value as? [String: AnyObject] {
////            self.userName = dictionary["Name"] as? String ?? ""
////          }
////
////        })
////        return userName
////      }
//
//        return userName
//    }
}

struct progressView_Previews: PreviewProvider {
    static var previews: some View {
        progressView()
            .rotationEffect(.init(degrees: 90.0))
    }
}
