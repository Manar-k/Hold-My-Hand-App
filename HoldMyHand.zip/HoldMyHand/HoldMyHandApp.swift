//
//  HoldMyHandApp.swift
//  HoldMyHand
//
//  Created by loka mloka on 20/07/1443 AH.
//

import SwiftUI
import Firebase

@main
struct HoldMyHandApp: App {
    init(){
        FirebaseApp.configure()
    }
    @StateObject private var userS = userSetting()
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(userS)
        }
    }
}
